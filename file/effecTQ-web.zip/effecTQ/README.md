# EffecTQ Training Plan Website

This is a repository for the final training plan developed for Grove Coffee, and serving as the final project for COM 453 at ASU. It was built using Bootstrap 3, and will continue to be developed until it's turned in.
